//declarar librerias
//pedir numero en una funcion
//sacar la raiz digital en una funcion
//realizar procedimiento
//cerrar programa
#include <stdio.h>
#include <stdlib.h>

int
pedir_numero(){
	int numero;
	printf("ingrese un numero\n");
	scanf("%d",&numero);
	return numero;
}

int raiz_digital(int numero){
	int raiz=0,modulo;
	while(numero!=0){
		modulo=(numero%10);
		raiz=(raiz+modulo);
		numero=(numero/10);
	}
	return modulo;
}
int main(){
	
	int numero;
	
	numero=pedir_numero();
	
	while(numero>9){
		numero=raiz_digital(numero);
}
	printf("%d",numero);
	return 0;
}
