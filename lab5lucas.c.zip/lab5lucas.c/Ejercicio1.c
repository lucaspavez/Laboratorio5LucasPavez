//Incluir librerias
//realizar funcion int 
//realizar procedimiento
//crear ciclo 
//llamar funcion en a y en b 
//imprimir los resultados
//preguntar si desea seguir 
//cerrar programa 
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int
Numero_aleatorio(){
	int x=rand()%10; 
	return x;
}

int main ()
{
	srand(time(NULL));
	int a,b,ganar=0,perder=0;
	char letra,seguir='s';
	printf("PROGRAMA DE APUESTAS\n");
	
	while(seguir=='s'){
		printf("Escoja A o B\n");
		scanf("%c",&letra);
		
		a=Numero_aleatorio();
		b=Numero_aleatorio();
		
		printf("A obtubo %d\n",a);
		printf("B obtubo %d\n",b);
		
		if (letra=='a' && a > b){
			ganar++;
			printf ("Ganó\n");
		}
		else if (letra=='b' && b > a){
			ganar++;
			printf("Ganó\n");
		}
		else{
			perder++;
			printf("Perdió\n");
		}
		printf("Lleva %d partidas ganadas\n",ganar);
		printf("Lleva %d partidas perdidas\n", perder);
	
		printf("si quiere seguir presione s y si no quiere presione n\n");
		scanf("%c",&seguir);
		while (getchar()!='\n');
		if (seguir=='n' || seguir=='N'){
			break;
		}
	}
	return 0;
}
